Python 3.7.0 (v3.7.0:1bf9cc5093, Jun 27 2018, 04:06:47) [MSC v.1914 32 bit (Intel)] on win32
Type "copyright", "credits" or "license()" for more information.
>>> import sqlite3
>>> def Create_Table():
	db = sqlite3.connect("Person.db")
	cursor = db.cursor()
	cursor.execute("create table person(id , Name , age)")
	cursor.close()
	db.close()

	
>>> def insert_m():
	connector = sqlite3.connect("Person.db")
	sql = "insert into person values(1 , 'Dominica' , '14')"
	connector.execute(sql)
	sql = "insert into person values(2 , 'Ruri' , '13')"
	connector.execute(sql)
	sql = "insert into person values(3 , 'Ruo' , '9')"
	connector.execute(sql)
	connector.commit()
	connector.close()

	
>>> def Select_M():
	connector = sqlite3.connect("Person.db")
	cursor = connector.cursor()
	cursor.execute("select * from person")
	result = cursor.fetchall()
	
	for row in result:
		print(row[1] + " 의 나이는 " + row[2] + " 입니다.")
	cursor.close()
	connector.close()

	
>>> if __name__=="__main__":
	Create_Table()
	insert_m()

	
Traceback (most recent call last):
  File "<pyshell#10>", line 2, in <module>
    Create_Table()
  File "<pyshell#2>", line 4, in Create_Table
    cursor.execute("create table person(id , Name , age)")
sqlite3.OperationalError: table person already exists
>>> if __name__="__main__":
	
SyntaxError: invalid syntax
>>> if __name__=="__main__":
	Select_M()

	
Dominica 의 나이는 14 입니다.
Ruri 의 나이는 13 입니다.
Ruo 의 나이는 9 입니다.
>>> 
